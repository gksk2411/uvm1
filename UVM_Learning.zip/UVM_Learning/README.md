# UVM_Learning
Documenting Journey of Exploring UVM  

|    Folder   | Description                                 | EDA Playground Link |
|-------------|---------------------------------------------|---------------------|
| Hello_World | Simple Test to print hello world | https://edaplayground.com/x/jbAW |
| Transaction_Example | Simple Example Demonsatrating Sequence Item Methods| https://edaplayground.com/x/NMnd |
| Single Port RAM | Single Port RAM with 2 different test cases | https://edaplayground.com/x/gpi7 |
| Up Down Counter | Up Down Counter Testbench, Reset from Top | https://edaplayground.com/x/gWYA |
| Get Port | UVM Get Port Example | https://edaplayground.com/x/QQJn |
| Put Port | UVM Put Port Example | https://edaplayground.com/x/WEks |
| FIFO | Synchronous FIFO Testbench, Reset from sequence | https://edaplayground.com/x/g5Gz |
| Pattern Detector | Pattern Detector Driver | https://edaplayground.com/x/PPzb |